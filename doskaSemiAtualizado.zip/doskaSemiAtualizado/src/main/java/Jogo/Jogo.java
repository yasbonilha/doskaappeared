
package Jogo;

public class Jogo {
    private String pontuacaoInicial;
    private String pontuacaoFinal;
    private String casaInicial;
    private String casaFinal = "1";
    private String posicaoInicial;
    private String posicaoFinal;

    //getters and setters
    public String getCasaInicial() {
        return casaInicial;
    }

    public void setCasaInicial(String casaInicial) {
        this.casaInicial = casaInicial;
    }

    public String getCasaFinal() {
        return casaFinal;
    }

    public void setCasaFinal(String casaFinal) {
        this.casaFinal = casaFinal;
    }
    
    
    //métodos:
    public int posicaoX(String casaInicial){
        int intCasaInicial = Integer.parseInt(casaInicial);
        switch(intCasaInicial){
            case 1:
            return 300;
            case 2:
                return 430;
            case 3:
                return 560;
            case 4:
                return 690;
            case 5:
                return 820;
            case 6:
                return 820;
            case 7:
                return 820;
            case 8:
                return 690;
            case 9:
                return 560;
            case 10:
                return 430;
            case 11:
                return 300;
            case 12:
                return 300;
            case 13:
                return 300;
            case 14:
                return 430;
            case 15:
                return 560;
            case 16:
                return 690;
            case 17:
                return 820;
            default:
                return 0;
        }
    }
    
    public int posicaoY(String casaInicial){
        int intCasaInicial = Integer.parseInt(casaInicial);
        switch(intCasaInicial){
            case 1:
            return 300;
            case 2:
                return 430;
            case 3:
                return 560;
            case 4:
                return 690;
            case 5:
                return 820;
            case 6:
                return 820;
            case 7:
                return 820;
            case 8:
                return 690;
            case 9:
                return 560;
            case 10:
                return 430;
            case 11:
                return 300;
            case 12:
                return 300;
            case 13:
                return 300;
            case 14:
                return 430;
            case 15:
                return 560;
            case 16:
                return 690;
            case 17:
                return 820;
            default:
                return 0;
        }
    }
    
   
}
