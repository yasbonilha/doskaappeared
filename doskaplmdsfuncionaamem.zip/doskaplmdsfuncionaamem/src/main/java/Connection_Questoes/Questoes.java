package Connection_Questoes;

public class Questoes {
    private int id;
    private String AlternativaA;
    private String AlternativaB;
    private String AlternativaC;
    private String AlternativaD;
    private String perguntas;
    private String respostas;

    public Questoes(int id) {
        this.id = id;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAlternativaA() {
        return AlternativaA;
    }

    public void setAlternativaA(String AlternativaA) {
        this.AlternativaA = AlternativaA;
    }

    public String getAlternativaB() {
        return AlternativaB;
    }

    public void setAlternativaB(String AlternativaB) {
        this.AlternativaB = AlternativaB;
    }

    public String getAlternativaC() {
        return AlternativaC;
    }

    public void setAlternativaC(String AlternativaC) {
        this.AlternativaC = AlternativaC;
    }

    public String getAlternativaD() {
        return AlternativaD;
    }

    public void setAlternativaD(String AlternativaD) {
        this.AlternativaD = AlternativaD;
    }

    public String getPerguntas() {
        return perguntas;
    }

    public void setPerguntas(String perguntas) {
        this.perguntas = perguntas;
    }

    public String getRespostas() {
        return respostas;
    }

    public void setRespostas(String respostas) {
        this.respostas = respostas;
    }
    
    
}
