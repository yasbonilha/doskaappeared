
package Jogo;

public class Jogo {
    private int pontuacaoInicial;
    private int pontuacaoFinal;
    private int casaInicial;
    private String casaFinal = "1";
    private int posicaoInicial;
    private int posicaoFinal;
}
