
package Jogo;

public class Jogo {
    private int pontuacaoInicial;
    private int pontuacaoFinal;
    private int casaInicial;
    private String casaFinal = "1";
    private int posicaoInicial;
    private int posicaoFinal;

    //construtores
    public Jogo(int pontuacaoInicial, int pontuacaoFinal) {
        this.pontuacaoInicial = pontuacaoInicial;
        this.pontuacaoFinal = pontuacaoFinal;
    }

    public Jogo() {
    }
    
    
     public String getCasaFinal() {
        return casaFinal;
    }
//casa
    public int xCasa(){
       String u = getCasaFinal();
       return 300 + u*130;
//           case 1:
//               return 300;
//           case 2:
//               return 430;
//           case 3:
//               return 560;
//           case 4:
//               return 690;
//           case 5:
//               return 820;
//           case 6:
//               return 820;
//           case 7:
//               return 820;
//           case 8:
//               return 690;
//           case 9:
//               return 560;
//           case 10:
//               return 430;
//           case 11:
//               return 300;
//           case 12:
//               return 300;
//           case 13:
//               return 300;
//           case 14:
//               return 430;
//           case 15:
//               return 560;
//           case 16:
//               return 690;
//           case 17:
//               return 820;
//           default:
//               return 0;
//       else if(casaFinal>5 && casaFinal){
//       }
       
    }
    
//getters n setters:
    public int getPontuacaoInicial() {
        return pontuacaoInicial;
    }

    public void setPontuacaoInicial(int pontuacaoInicial) {
        this.pontuacaoInicial = pontuacaoInicial;
    }

    public int getPontuacaoFinal() {
        return pontuacaoFinal;
    }

    public void setPontuacaoFinal(int pontuacaoFinal) {
        this.pontuacaoFinal = pontuacaoFinal;
    }

    public int getCasaInicial() {
        return casaInicial;
    }

    public void setCasaInicial(int casaInicial) {
        this.casaInicial = casaInicial;
    }

    public void setCasaFinal(int casaFinal) {
        this.casaFinal = casaFinal;
    }

    public int getPosicaoInicial() {
        return posicaoInicial;
    }

    public void setPosicaoInicial(int posicaoInicial) {
        this.posicaoInicial = posicaoInicial;
    }

    public int getPosicaoFinal() {
        return posicaoFinal;
    }

    public void setPosicaoFinal(int posicaoFinal) {
        this.posicaoFinal = posicaoFinal;
    }
    
    
}
